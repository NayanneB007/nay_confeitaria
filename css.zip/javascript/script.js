
function entrar(event) {
    event.preventDefault();

    alert("Login realizado para demonstração!");

    window.location.href = "menu.html";
}

function cadastrar(event) {
    event.preventDefault();

    alert("Cadastro realizado para demonstração!");

    window.location.href = "login.html";
}

function enviarContato(event) {
    event.preventDefault();

    alert("Mensagem enviada para demonstração!");
}

function sair() {
    alert("Você saiu do sistema.");

    window.location.href = "index.html";
}
